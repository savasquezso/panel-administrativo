<?php
include 'db_connection.php';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->query("SELECT COUNT(*) FROM proveedores");
    $totalProveedores = $stmt->fetchColumn();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    $totalProveedores = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="pagina.css">

</head>

<body>
    <div class="sidebar">
        <img src="" alt="" class="logo">
        <nav>
            <div class="nav-item">
                <a href="principal.php" class="nav-link active">Panel principal</a>
            </div>
            <div class="nav-item">
                <a href="ventas.php" class="nav-link">Analisis & Ventas</a>
            </div>
            <div class="nav-item">
                <a href="proveedor.php" class="nav-link">Proveedores</a>
            </div>
            <div class="nav-item">
                <a href="producto.php" class="nav-link">Productos</a>
            </div>
            <div class="nav-item">
                <a href="usuario.php" class="nav-link">Usuarios</a>
            </div>
        </nav>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Dashboard</h1>
            <button class="btn">Salir</button><!-- Agregar llamado salida *salida.php*-->
        </div>

        <div class="card-container">
            <div class="card">
                <h6>Ventas totales</h6>
                <h3>$24,568</h3>
                <div class="small success">3.5% incremento</div>
            </div>
            <div class="card">
                <h6>Total ordenes</h6>
                <h3>1,286</h3>
                <div class="small danger">1.2% disminucion</div>
            </div>
            <div class="card">
                <h6>Total proveedores</h6>
                <h3><?php echo $totalProveedores; ?></h3>
                <div class="small success">
                    <?php
                    // Ejemplo de incremento ficticio para mostrar
                    $incremento = $totalProveedores * 0.1;
                    echo number_format($incremento, 1) . '% incremento';
                    ?>
                </div>
            </div>
            <div class="card">
                <h6>Ganancias</h6>
                <h3>$779.140</h3>
                <div class="small success">5.2% ingresos</div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card-stad">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ventas</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="salesChart" height="300"></canvas>
                    </div>
                </div>
            </div>

            <div class="dashboard-cards-prueba">
                <!-- Nueva Tarjeta -->
                <div class="card-prueba">
                    <div class="card-header-prueba">
                        <h4>Nueva Tarjeta</h4>
                    </div>
                    <div class="card-body-prueba">
                        <p>Este es el contenido de la nueva tarjeta.</p>
                    </div>
                </div>
            </div>
            <div class="card-P">
                <h3>Pedidos Recientes</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID pedido</th>
                            <th>Proveedor</th>
                            <th>Producto</th>
                            <th>Costo</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#12345</td>
                            <td>
                                <img src="https://via.placeholder.com/40" alt="Avatar" class="avatar">
                                Frutas
                            </td>
                            <td>Producto A</td>
                            <td>$123.450</td>
                            <td><span class="badge badge-success">Completado</span></td>
                        </tr>
                        <tr>
                            <td>#12346</td>
                            <td>
                                <img src="https://via.placeholder.com/40" alt="Avatar" class="avatar">
                                Especias
                            </td>
                            <td>Producto B</td>
                            <td>$98.760</td>
                            <td><span class="badge badge-warning">Pendiente</span></td>
                        </tr>
                        <tr>
                            <td>#12347</td>
                            <td>
                                <img src="https://via.placeholder.com/40" alt="Avatar" class="avatar">

                            </td>
                            <td>Producto C</td>
                            <td>$45.670</td>
                            <td><span class="badge badge-danger">Cancelado</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            // Sales Chart
            const ctx = document.getElementById('salesChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Sales',
                        data: [12, 19, 3, 5, 2, 3],
                        borderColor: '#2c7be5',
                        tension: 0.1
                    }]

                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
</body>

</html>